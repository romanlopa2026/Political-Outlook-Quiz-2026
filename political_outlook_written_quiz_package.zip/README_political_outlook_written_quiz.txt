POLITICAL OUTLOOK — WRITTEN REFLECTION VERSION

FILES
- political_outlook_written_quiz.html: open this in a browser to use the written quiz.
- political_outlook_embed_code.txt: the complete HTML source if you are hosting the quiz somewhere.

HOW IT WORKS
1. Open political_outlook_written_quiz.html in a browser.
2. Answer the 15 main written questions. Optional context questions can all be skipped. There are no follow-up questions.
3. Click “Generate my analysis packet.”
4. Click “Copy packet.”
5. Open ChatGPT, paste the packet into a message, and send it. ChatGPT will provide a neutral written analysis based on the responses.

IMPORTANT
The quiz page itself does not call an AI model and does not automatically determine a political outlook. It packages the answers and instructions for analysis by ChatGPT. Answers remain in the current browser page unless the user copies/downloads them; refreshing or closing may lose them.

GOOGLE SITES
Google Sites often restricts JavaScript pasted directly into an embed-code box. The most reliable method is to host the HTML file on a service that supports static HTML, then in Google Sites choose Insert > Embed > By URL and enter the hosted page URL. The HTML file by itself is not yet a public website.
